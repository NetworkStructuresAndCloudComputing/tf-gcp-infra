const mailgun = require('mailgun-js');
const DOMAIN = 'sandbox-123.mailgun.org';
const mg = mailgun({ apiKey: 'f24cb9dcb382bf4e5165f8f5d2a6969e-309b0ef4-88a25bb0', domain: "mg.cloudcomputingzakirmemon.me" });

exports.sendVerificationEmail = async (req, res) => {
  try {
    const data = {
      from: 'Excited User <mailgun@sandbox-123.mailgun.org>',
      to: 'aayush.shetty12@gmail.com',
      subject: 'Hello',
      text: 'Please click the following link to verify your email address: verificationLink',
      html: '<h1>Testing some Mailgun awesomeness!</h1>'
    };

    await mg.messages().send(data);
    console.log('Verification email sent successfully.');
    res.status(200).send('Verification email sent successfully.');
  } catch (error) {
    console.error('Error sending verification email:', error);
    res.status(500).send('Error sending verification email.');
  }
};